var unlayer = (function(e) {
	var t = {};
	function s(i) {
		if (t[i]) return t[i].exports;
		var a = (t[i] = { i: i, l: !1, exports: {} });
		return e[i].call(a.exports, a, a.exports, s), (a.l = !0), a.exports;
	}
	return (
		(s.m = e),
		(s.c = t),
		(s.d = function(e, t, i) {
			s.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: i });
		}),
		(s.r = function(e) {
			"undefined" != typeof Symbol &&
				Symbol.toStringTag &&
				Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
				Object.defineProperty(e, "__esModule", { value: !0 });
		}),
		(s.t = function(e, t) {
			if ((1 & t && (e = s(e)), 8 & t)) return e;
			if (4 & t && "object" == typeof e && e && e.__esModule) return e;
			var i = Object.create(null);
			if (
				(s.r(i),
				Object.defineProperty(i, "default", { enumerable: !0, value: e }),
				2 & t && "string" != typeof e)
			)
				for (var a in e)
					s.d(
						i,
						a,
						function(t) {
							return e[t];
						}.bind(null, a)
					);
			return i;
		}),
		(s.n = function(e) {
			var t =
				e && e.__esModule
					? function() {
							return e.default;
					  }
					: function() {
							return e;
					  };
			return s.d(t, "a", t), t;
		}),
		(s.o = function(e, t) {
			return Object.prototype.hasOwnProperty.call(e, t);
		}),
		(s.p = "/"),
		s((s.s = 0))
	);
})([
	function(e, t, s) {
		s(1), s(2), s(3), (e.exports = s(4));
	},
	function(e, t) {
		(Window.prototype.forceJURL = !1),
			(function(e) {
				"use strict";
				var t = !1;
				if (!e.forceJURL)
					try {
						var s = new URL("b", "http://a");
						(s.pathname = "c%20d"), (t = "http://a/c%20d" === s.href);
					} catch (e) {}
				if (!t) {
					var i = Object.create(null);
					(i.ftp = 21),
						(i.file = 0),
						(i.gopher = 70),
						(i.http = 80),
						(i.https = 443),
						(i.ws = 80),
						(i.wss = 443);
					var a = Object.create(null);
					(a["%2e"] = "."),
						(a[".%2e"] = ".."),
						(a["%2e."] = ".."),
						(a["%2e%2e"] = "..");
					var n = void 0,
						r = /[a-zA-Z]/,
						o = /[a-zA-Z0-9\+\-\.]/;
					_.prototype = {
						toString: function() {
							return this.href;
						},
						get href() {
							if (this._isInvalid) return this._url;
							var e = "";
							return (
								("" == this._username && null == this._password) ||
									(e =
										this._username +
										(null != this._password ? ":" + this._password : "") +
										"@"),
								this.protocol +
									(this._isRelative ? "//" + e + this.host : "") +
									this.pathname +
									this._query +
									this._fragment
							);
						},
						set href(e) {
							g.call(this), p.call(this, e);
						},
						get protocol() {
							return this._scheme + ":";
						},
						set protocol(e) {
							this._isInvalid || p.call(this, e + ":", "scheme start");
						},
						get host() {
							return this._isInvalid
								? ""
								: this._port
								? this._host + ":" + this._port
								: this._host;
						},
						set host(e) {
							!this._isInvalid && this._isRelative && p.call(this, e, "host");
						},
						get hostname() {
							return this._host;
						},
						set hostname(e) {
							!this._isInvalid &&
								this._isRelative &&
								p.call(this, e, "hostname");
						},
						get port() {
							return this._port;
						},
						set port(e) {
							!this._isInvalid && this._isRelative && p.call(this, e, "port");
						},
						get pathname() {
							return this._isInvalid
								? ""
								: this._isRelative
								? "/" + this._path.join("/")
								: this._schemeData;
						},
						set pathname(e) {
							!this._isInvalid &&
								this._isRelative &&
								((this._path = []), p.call(this, e, "relative path start"));
						},
						get search() {
							return this._isInvalid || !this._query || "?" == this._query
								? ""
								: this._query;
						},
						set search(e) {
							!this._isInvalid &&
								this._isRelative &&
								((this._query = "?"),
								"?" == e[0] && (e = e.slice(1)),
								p.call(this, e, "query"));
						},
						get hash() {
							return this._isInvalid || !this._fragment || "#" == this._fragment
								? ""
								: this._fragment;
						},
						set hash(e) {
							this._isInvalid ||
								(e
									? ((this._fragment = "#"),
									  "#" == e[0] && (e = e.slice(1)),
									  p.call(this, e, "fragment"))
									: (this._fragment = ""));
						},
						get origin() {
							var e;
							if (this._isInvalid || !this._scheme) return "";
							switch (this._scheme) {
								case "data":
								case "file":
								case "javascript":
								case "mailto":
									return "null";
							}
							return (e = this.host) ? this._scheme + "://" + e : "";
						}
					};
					var h = e.URL;
					h &&
						((_.createObjectURL = function(e) {
							return h.createObjectURL.apply(h, arguments);
						}),
						(_.revokeObjectURL = function(e) {
							h.revokeObjectURL(e);
						})),
						(e.URL = _);
				}
				function c(e) {
					return void 0 !== i[e];
				}
				function l() {
					g.call(this), (this._isInvalid = !0);
				}
				function u(e) {
					return "" == e && l.call(this), e.toLowerCase();
				}
				function f(e) {
					var t = e.charCodeAt(0);
					return t > 32 && t < 127 && -1 == [34, 35, 60, 62, 63, 96].indexOf(t)
						? e
						: encodeURIComponent(e);
				}
				function d(e) {
					var t = e.charCodeAt(0);
					return t > 32 && t < 127 && -1 == [34, 35, 60, 62, 96].indexOf(t)
						? e
						: encodeURIComponent(e);
				}
				function p(e, t, s) {
					function h(e) {
						y.push(e);
					}
					var p = t || "scheme start",
						g = 0,
						_ = "",
						m = !1,
						v = !1,
						y = [];
					e: for (; (e[g - 1] != n || 0 == g) && !this._isInvalid; ) {
						var b = e[g];
						switch (p) {
							case "scheme start":
								if (!b || !r.test(b)) {
									if (t) {
										h("Invalid scheme.");
										break e;
									}
									(_ = ""), (p = "no scheme");
									continue;
								}
								(_ += b.toLowerCase()), (p = "scheme");
								break;
							case "scheme":
								if (b && o.test(b)) _ += b.toLowerCase();
								else {
									if (":" != b) {
										if (t) {
											if (n == b) break e;
											h("Code point not allowed in scheme: " + b);
											break e;
										}
										(_ = ""), (g = 0), (p = "no scheme");
										continue;
									}
									if (((this._scheme = _), (_ = ""), t)) break e;
									c(this._scheme) && (this._isRelative = !0),
										(p =
											"file" == this._scheme
												? "relative"
												: this._isRelative && s && s._scheme == this._scheme
												? "relative or authority"
												: this._isRelative
												? "authority first slash"
												: "scheme data");
								}
								break;
							case "scheme data":
								"?" == b
									? ((this._query = "?"), (p = "query"))
									: "#" == b
									? ((this._fragment = "#"), (p = "fragment"))
									: n != b &&
									  "\t" != b &&
									  "\n" != b &&
									  "\r" != b &&
									  (this._schemeData += f(b));
								break;
							case "no scheme":
								if (s && c(s._scheme)) {
									p = "relative";
									continue;
								}
								h("Missing scheme."), l.call(this);
								break;
							case "relative or authority":
								if ("/" != b || "/" != e[g + 1]) {
									h("Expected /, got: " + b), (p = "relative");
									continue;
								}
								p = "authority ignore slashes";
								break;
							case "relative":
								if (
									((this._isRelative = !0),
									"file" != this._scheme && (this._scheme = s._scheme),
									n == b)
								) {
									(this._host = s._host),
										(this._port = s._port),
										(this._path = s._path.slice()),
										(this._query = s._query),
										(this._username = s._username),
										(this._password = s._password);
									break e;
								}
								if ("/" == b || "\\" == b)
									"\\" == b && h("\\ is an invalid code point."),
										(p = "relative slash");
								else if ("?" == b)
									(this._host = s._host),
										(this._port = s._port),
										(this._path = s._path.slice()),
										(this._query = "?"),
										(this._username = s._username),
										(this._password = s._password),
										(p = "query");
								else {
									if ("#" != b) {
										var w = e[g + 1],
											M = e[g + 2];
										("file" != this._scheme ||
											!r.test(b) ||
											(":" != w && "|" != w) ||
											(n != M &&
												"/" != M &&
												"\\" != M &&
												"?" != M &&
												"#" != M)) &&
											((this._host = s._host),
											(this._port = s._port),
											(this._username = s._username),
											(this._password = s._password),
											(this._path = s._path.slice()),
											this._path.pop()),
											(p = "relative path");
										continue;
									}
									(this._host = s._host),
										(this._port = s._port),
										(this._path = s._path.slice()),
										(this._query = s._query),
										(this._fragment = "#"),
										(this._username = s._username),
										(this._password = s._password),
										(p = "fragment");
								}
								break;
							case "relative slash":
								if ("/" != b && "\\" != b) {
									"file" != this._scheme &&
										((this._host = s._host),
										(this._port = s._port),
										(this._username = s._username),
										(this._password = s._password)),
										(p = "relative path");
									continue;
								}
								"\\" == b && h("\\ is an invalid code point."),
									(p =
										"file" == this._scheme
											? "file host"
											: "authority ignore slashes");
								break;
							case "authority first slash":
								if ("/" != b) {
									h("Expected '/', got: " + b),
										(p = "authority ignore slashes");
									continue;
								}
								p = "authority second slash";
								break;
							case "authority second slash":
								if (((p = "authority ignore slashes"), "/" != b)) {
									h("Expected '/', got: " + b);
									continue;
								}
								break;
							case "authority ignore slashes":
								if ("/" != b && "\\" != b) {
									p = "authority";
									continue;
								}
								h("Expected authority, got: " + b);
								break;
							case "authority":
								if ("@" == b) {
									m && (h("@ already seen."), (_ += "%40")), (m = !0);
									for (var k = 0; k < _.length; k++) {
										var I = _[k];
										if ("\t" != I && "\n" != I && "\r" != I)
											if (":" != I || null !== this._password) {
												var T = f(I);
												null !== this._password
													? (this._password += T)
													: (this._username += T);
											} else this._password = "";
										else h("Invalid whitespace in authority.");
									}
									_ = "";
								} else {
									if (n == b || "/" == b || "\\" == b || "?" == b || "#" == b) {
										(g -= _.length), (_ = ""), (p = "host");
										continue;
									}
									_ += b;
								}
								break;
							case "file host":
								if (n == b || "/" == b || "\\" == b || "?" == b || "#" == b) {
									2 != _.length || !r.test(_[0]) || (":" != _[1] && "|" != _[1])
										? 0 == _.length
											? (p = "relative path start")
											: ((this._host = u.call(this, _)),
											  (_ = ""),
											  (p = "relative path start"))
										: (p = "relative path");
									continue;
								}
								"\t" == b || "\n" == b || "\r" == b
									? h("Invalid whitespace in file host.")
									: (_ += b);
								break;
							case "host":
							case "hostname":
								if (":" != b || v) {
									if (n == b || "/" == b || "\\" == b || "?" == b || "#" == b) {
										if (
											((this._host = u.call(this, _)),
											(_ = ""),
											(p = "relative path start"),
											t)
										)
											break e;
										continue;
									}
									"\t" != b && "\n" != b && "\r" != b
										? ("[" == b ? (v = !0) : "]" == b && (v = !1), (_ += b))
										: h("Invalid code point in host/hostname: " + b);
								} else if (
									((this._host = u.call(this, _)),
									(_ = ""),
									(p = "port"),
									"hostname" == t)
								)
									break e;
								break;
							case "port":
								if (/[0-9]/.test(b)) _ += b;
								else {
									if (
										n == b ||
										"/" == b ||
										"\\" == b ||
										"?" == b ||
										"#" == b ||
										t
									) {
										if ("" != _) {
											var C = parseInt(_, 10);
											C != i[this._scheme] && (this._port = C + ""), (_ = "");
										}
										if (t) break e;
										p = "relative path start";
										continue;
									}
									"\t" == b || "\n" == b || "\r" == b
										? h("Invalid code point in port: " + b)
										: l.call(this);
								}
								break;
							case "relative path start":
								if (
									("\\" == b && h("'\\' not allowed in path."),
									(p = "relative path"),
									"/" != b && "\\" != b)
								)
									continue;
								break;
							case "relative path":
								var j;
								if (
									n != b &&
									"/" != b &&
									"\\" != b &&
									(t || ("?" != b && "#" != b))
								)
									"\t" != b && "\n" != b && "\r" != b && (_ += f(b));
								else
									"\\" == b && h("\\ not allowed in relative path."),
										(j = a[_.toLowerCase()]) && (_ = j),
										".." == _
											? (this._path.pop(),
											  "/" != b && "\\" != b && this._path.push(""))
											: "." == _ && "/" != b && "\\" != b
											? this._path.push("")
											: "." != _ &&
											  ("file" == this._scheme &&
													0 == this._path.length &&
													2 == _.length &&
													r.test(_[0]) &&
													"|" == _[1] &&
													(_ = _[0] + ":"),
											  this._path.push(_)),
										(_ = ""),
										"?" == b
											? ((this._query = "?"), (p = "query"))
											: "#" == b && ((this._fragment = "#"), (p = "fragment"));
								break;
							case "query":
								t || "#" != b
									? n != b &&
									  "\t" != b &&
									  "\n" != b &&
									  "\r" != b &&
									  (this._query += d(b))
									: ((this._fragment = "#"), (p = "fragment"));
								break;
							case "fragment":
								n != b &&
									"\t" != b &&
									"\n" != b &&
									"\r" != b &&
									(this._fragment += b);
						}
						g++;
					}
				}
				function g() {
					(this._scheme = ""),
						(this._schemeData = ""),
						(this._username = ""),
						(this._password = null),
						(this._host = ""),
						(this._port = ""),
						(this._path = []),
						(this._query = ""),
						(this._fragment = ""),
						(this._isInvalid = !1),
						(this._isRelative = !1);
				}
				function _(e, t) {
					void 0 === t || t instanceof _ || (t = new _(String(t))),
						(this._url = "" + e),
						g.call(this);
					var s = this._url.replace(/^[ \t\r\n\f]+|[ \t\r\n\f]+$/g, "");
					p.call(this, s, null, t);
				}
			})(window);
	},
	function(e, t) {
		!(function(e) {
			var t = e.getElementsByTagName("script");
			"currentScript" in e ||
				Object.defineProperty(e, "currentScript", {
					get: function() {
						try {
							throw new Error();
						} catch (i) {
							var e,
								s = (/.*at [^\(]*\((.*):.+:.+\)$/gi.exec(i.stack) || [!1])[1];
							for (e in t)
								if (t[e].src == s || "interactive" == t[e].readyState)
									return t[e];
							return null;
						}
					}
				});
		})(document);
	},
	function(e, t, s) {
		var i = new URL(document.currentScript.src),
			a = i.href.substring(0, i.href.lastIndexOf("/") + 1);
		s.p = a;
	},
	function(e, t, s) {
		"use strict";
		function i(e) {
			for (var t = 1; t < arguments.length; t++) {
				var s = null != arguments[t] ? arguments[t] : {},
					i = Object.keys(s);
				"function" == typeof Object.getOwnPropertySymbols &&
					(i = i.concat(
						Object.getOwnPropertySymbols(s).filter(function(e) {
							return Object.getOwnPropertyDescriptor(s, e).enumerable;
						})
					)),
					i.forEach(function(t) {
						a(e, t, s[t]);
					});
			}
			return e;
		}
		function a(e, t, s) {
			return (
				t in e
					? Object.defineProperty(e, t, {
							value: s,
							enumerable: !0,
							configurable: !0,
							writable: !0
					  })
					: (e[t] = s),
				e
			);
		}
		function n(e, t) {
			for (var s = 0; s < t.length; s++) {
				var i = t[s];
				(i.enumerable = i.enumerable || !1),
					(i.configurable = !0),
					"value" in i && (i.writable = !0),
					Object.defineProperty(e, i.key, i);
			}
		}
		s.r(t);
		var r,
			o = function(e) {
				var t = document.createElement("iframe");
				return (
					(t.src = e),
					(t.frameBorder = 0),
					(t.width = "100%"),
					(t.height = "100%"),
					(t.style.minWidth = "1024px"),
					(t.style.minHeight = "100%"),
					(t.style.height = "100%"),
					(t.style.width = "100%"),
					(t.style.border = "0px"),
					t
				);
			},
			h = (function() {
				function e(t) {
					var s = this;
					!(function(e, t) {
						if (!(e instanceof t))
							throw new TypeError("Cannot call a class as a function");
					})(this, e),
						(this.ready = !1),
						(this.iframe = o(t)),
						(this.messages = []),
						(this.iframe.onload = function() {
							(s.ready = !0), s.flushMessages();
						}),
						(this.callbackId = 0),
						(this.callbacks = {});
				}
				var t, s, a;
				return (
					(t = e),
					(s = [
						{
							key: "appendTo",
							value: function(e) {
								e.appendChild(this.iframe);
							}
						},
						{
							key: "postMessage",
							value: function(e, t) {
								this.scheduleMessage(i({ action: e }, t)), this.flushMessages();
							}
						},
						{
							key: "withMessage",
							value: function(e, t, s) {
								var a = this.callbackId++;
								(this.callbacks[a] = s),
									this.postMessage(e, i({ callbackId: a }, t));
							}
						},
						{
							key: "scheduleMessage",
							value: function(e) {
								this.messages.push(e);
							}
						},
						{
							key: "flushMessages",
							value: function() {
								var e = this;
								this.ready &&
									(this.messages.forEach(function(t) {
										e.iframe.contentWindow.postMessage(t, "*");
									}),
									(this.messages = []));
							}
						},
						{
							key: "handleMessage",
							value: function(e) {
								var t = this,
									s = e.action,
									i = e.callbackId,
									a = e.doneId,
									n = e.result;
								switch (s) {
									case "response":
										this.callbacks[i](n), delete this.callbacks[i];
										break;
									case "callback":
										n.attachments &&
											(n.attachments = n.attachments.map(function(e) {
												return new File([e.content], e.name, { type: e.type });
											})),
											this.callbacks[i](n, function(e) {
												t.postMessage("done", { doneId: a, result: e });
											});
								}
							}
						},
						{
							key: "receiveMessage",
							value: function(e) {
								e.data && this.handleMessage(e.data);
							}
						}
					]) && n(t.prototype, s),
					a && n(t, a),
					e
				);
			})();
		s.d(t, "init", function() {
			return c;
		}),
			s.d(t, "registerCallback", function() {
				return l;
			}),
			s.d(t, "unregisterCallback", function() {
				return u;
			}),
			s.d(t, "registerProvider", function() {
				return f;
			}),
			s.d(t, "unregisterProvider", function() {
				return d;
			}),
			s.d(t, "reloadProvider", function() {
				return p;
			}),
			s.d(t, "addEventListener", function() {
				return g;
			}),
			s.d(t, "removeEventListener", function() {
				return _;
			}),
			s.d(t, "setDesignMode", function() {
				return m;
			}),
			s.d(t, "setDisplayMode", function() {
				return v;
			}),
			s.d(t, "loadProject", function() {
				return y;
			}),
			s.d(t, "loadUser", function() {
				return b;
			}),
			s.d(t, "loadTemplate", function() {
				return w;
			}),
			s.d(t, "setMergeTags", function() {
				return M;
			}),
			s.d(t, "setLocale", function() {
				return k;
			}),
			s.d(t, "setTranslations", function() {
				return I;
			}),
			s.d(t, "loadBlank", function() {
				return T;
			}),
			s.d(t, "loadDesign", function() {
				return C;
			}),
			s.d(t, "saveDesign", function() {
				return j;
			}),
			s.d(t, "exportHtml", function() {
				return O;
			}),
			s.d(t, "exportLiveHtml", function() {
				return R;
			}),
			s.d(t, "setAppearance", function() {
				return x;
			}),
			s.d(t, "setDesignTagsConfig", function() {
				return L;
			}),
			s.d(t, "setMergeTagsConfig", function() {
				return S;
			});
		var c = function(e) {
				var t;
				if (
					(e.id
						? (t = document.getElementById(e.id))
						: e.className &&
						  (t = document.getElementsByClassName(e.className)[0]),
					!t)
				)
					throw new Error("id or className must be provided.");
				var i = e.version || "1.0.28",
					a = "".concat(s.p).concat(i, "/editor.html"),
					n = e.offline ? a + "?offline=true" : a;
				(r = new h(n)).appendTo(t);
				var o = {};
				e.designMode && (o.designMode = e.designMode),
					e.displayMode && (o.displayMode = e.displayMode),
					e.projectId && (o.projectId = e.projectId),
					e.user && (o.user = e.user),
					e.templateId && (o.templateId = e.templateId),
					e.loadTimeout && (o.loadTimeout = e.loadTimeout),
					(e.safeHtml || e.safeHTML) && (o.safeHtml = !0),
					e.options && (o.options = e.options),
					e.tools && (o.tools = e.tools),
					e.excludeTools && (o.excludeTools = e.excludeTools),
					e.blocks && (o.blocks = e.blocks),
					e.editor && (o.editor = e.editor),
					e.fonts && (o.fonts = e.fonts),
					e.mergeTags && (o.mergeTags = e.mergeTags),
					e.designTags && (o.designTags = e.designTags),
					e.customCSS && (o.customCSS = e.customCSS),
					e.customJS && (o.customJS = e.customJS),
					e.locale && (o.locale = e.locale),
					e.translations && (o.translations = e.translations),
					e.appearance && (o.appearance = e.appearance),
					e.features && (o.features = e.features),
					e.designTagsConfig && (o.designTagsConfig = e.designTagsConfig),
					e.mergeTagsConfig && (o.mergeTagsConfig = e.mergeTagsConfig),
					r.postMessage("config", o);
			},
			l = function(e, t) {
				r.withMessage("registerCallback", { type: e }, t);
			},
			u = function(e) {
				r.withMessage("unregisterCallback", { type: e });
			},
			f = function(e, t) {
				r.withMessage("registerProvider", { type: e }, t);
			},
			d = function(e) {
				r.withMessage("unregisterProvider", { type: e });
			},
			p = function(e) {
				r.withMessage("reloadProvider", { type: e });
			},
			g = function(e, t) {
				r.withMessage("registerCallback", { type: e }, t);
			},
			_ = function(e) {
				r.withMessage("unregisterCallback", { type: e });
			},
			m = function(e) {
				r.withMessage("setDesignMode", { designMode: e });
			},
			v = function(e) {
				r.withMessage("setDisplayMode", { displayMode: e });
			},
			y = function(e) {
				r.postMessage("loadProject", { projectId: e });
			},
			b = function(e) {
				r.postMessage("loadUser", { user: e });
			},
			w = function(e) {
				r.postMessage("loadTemplate", { templateId: e });
			},
			M = function(e) {
				r.postMessage("setMergeTags", { mergeTags: e });
			},
			k = function(e) {
				r.postMessage("setLocale", { locale: e });
			},
			I = function(e) {
				r.postMessage("setTranslations", { translations: e });
			},
			T = function() {
				r.postMessage("loadBlank", {});
			},
			C = function(e) {
				r.postMessage("loadDesign", { design: e });
			},
			j = function(e) {
				r.withMessage("saveDesign", {}, e);
			},
			O = function(e) {
				r.withMessage("exportHtml", {}, e);
			},
			R = function(e) {
				r.withMessage("exportLiveHtml", {}, e);
			},
			x = function(e) {
				r.postMessage("setAppearance", { appearance: e });
			},
			L = function(e) {
				r.postMessage("setDesignTagsConfig", { designTagsConfig: e });
			},
			S = function(e) {
				r.postMessage("setMergeTagsConfig", { mergeTagsConfig: e });
			};
		window.addEventListener(
			"message",
			function(e) {
				r && r.receiveMessage(e);
			},
			!1
		);
	}
]);
