/** @format */

export { default as withStyles } from "./withStyles";
