import { createContext } from 'react';

const ApiDataContext = createContext({});

export default ApiDataContext;