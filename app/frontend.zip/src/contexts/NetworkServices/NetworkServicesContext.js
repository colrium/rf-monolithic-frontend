import { createContext } from 'react';

const NetworkServicesContext = createContext(undefined);

export default NetworkServicesContext;